'''
About Vengaboys song
Album: The Party Album
Artist: Vengaboys
Released: 1998
'''

#name of the Album
Album = "The Party Album"

#name of the Artist
Artist = "Vengaboys"

#Released Year
ReleasedYear = 1998

print("AlAlbum Name : " + Album)
print("Artist Name : " + Artist)
print("Released Year : " + str(ReleasedYear))