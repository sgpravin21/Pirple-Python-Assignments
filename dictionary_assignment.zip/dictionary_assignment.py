'''
Homework Assignment #7: Dictionaries and Sets
'''

oDic={'Album':'The Party Album', 'Artist':'Vengaboys', 'ReleasedYear':'1998'}

print("Complete dictionary :")
print(oDic.items())

print("\nkeys & Values in the Dictionary:")
for i in oDic.items():
    print(i)


